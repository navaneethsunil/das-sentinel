import hashlib

def h(x):
    return hashlib.md5(x).hexdigest()
